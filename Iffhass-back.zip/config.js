module.exports = {
    "AWS": {
        "accessKeyId": "AKIASO6JFGGUD2XNE5XU",
        "secretAccessKey": "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",
        "region": "us-east-2"
    },
    "ImageKit": {
        publicKey: "public_051lKBIDHvP92nS3tPmHG1c06to=",
        privateKey: "private_W37wnJIZ62bdCk9AHeyPW/9XLIY=",
        urlEndpoint: "https://ik.imagekit.io/6jmfzel6y"
    }
}